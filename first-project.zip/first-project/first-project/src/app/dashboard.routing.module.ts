import { Routes, RouterModule } from '@angular/router'
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { LoginService } from './login/login.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import { MatTableModule } from '@angular/material/table'
import { MatPaginatorModule } from '@angular/material/paginator';
import { AuthService } from './services/authentication.service';
import { MatSortModule } from '@angular/material/sort';
import { MatToolbarModule } from '@angular/material/toolbar'
import { MatIconModule } from '@angular/material/icon';
import { CreateQuoteComponent } from './create-quote/create-quote.component'
import { MatSelectModule } from '@angular/material/select';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MenubarComponent } from './menubar/menubar.component';
import { MatStepperModule } from '@angular/material/stepper';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
// import {MatMomentDateModule} from '@angular/material-moment-adapter';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { QuoteListComponent } from './quote-list/quote-list.component';
import {MatMenuModule} from '@angular/material/menu';
import {MatSidenavModule} from '@angular/material/sidenav';
import{MatListModule} from '@angular/material/list';


export const routes: Routes = [
    // { path: 'login', component: LoginComponent, },
    { path: '', redirectTo: '/dashboard', pathMatch: 'full' },
    {
        path: 'dashboard', component: DashboardComponent, children: [
            // { path: 'home', component: HomeComponent },
            // { path: 'editpolicy', component: CreateQuoteComponent, data: { viewOption: 'update' } },
            // { path: 'createpolicy', component: CreateQuoteComponent, data: { viewOption: 'create' } },
            // {path:'quote-list',component:QuoteListComponent}
            // {path:'employees',component:EmployeeListComponent}
        ]
    },

]
@NgModule({
    declarations: [
        LoginComponent,
        DashboardComponent,
        HomeComponent,
        CreateQuoteComponent,MenubarComponent,
        QuoteListComponent
    ],
    imports: [
        RouterModule.forChild(routes),
        BrowserModule,
        BrowserAnimationsModule,
        MatCardModule,
        MatInputModule,
        MatButtonModule,
        FormsModule,
        ReactiveFormsModule,
        HttpClientModule,
        MatTableModule,
        MatPaginatorModule,
        MatSortModule,
        MatToolbarModule,
        MatIconModule,
        MatSelectModule,
        MatStepperModule,
        MatDatepickerModule,
        MatNativeDateModule,
        // MatMomentDateModule,
        MatSnackBarModule,
        MatMenuModule,
        MatSidenavModule,
        MatListModule
    ],
    exports:[RouterModule]
})
export class DashboardRoutingModule { }