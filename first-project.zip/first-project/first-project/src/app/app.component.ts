import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from './login/login.service';
import { routes } from './app.module';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'first-project';

  username!:string;
  logOut:boolean=false;
  routes = routes;

  constructor(private loginSrv:LoginService,private router:Router) { }

  getProfile(){
    // this.loginSrv.getProfile()!.pipe().subscribe((res:any)=>{
    //    this.username=res.data.name;
    // })
  }
  ngOnInit(){
    // this.getProfile();
  }
  logout(){
    this.router.navigate(['/login']);
  }
}
