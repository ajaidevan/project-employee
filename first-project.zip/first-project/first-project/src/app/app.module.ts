import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { Route, RouterModule } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './login/login.component';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { LoginService } from './login/login.service';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HomeComponent } from './home/home.component';
import {MatTableModule} from '@angular/material/table'
import { MatPaginatorModule } from '@angular/material/paginator';
import { AuthService } from './services/authentication.service';
import { MatSortModule } from '@angular/material/sort';
import {MatToolbarModule} from '@angular/material/toolbar'
import {MatIconModule} from '@angular/material/icon';
import { CreateQuoteComponent } from './create-quote/create-quote.component'
import {MatSelectModule} from '@angular/material/select';
import { DashboardComponent } from './dashboard/dashboard.component';
import { MenubarComponent } from './menubar/menubar.component';
import {MatStepperModule} from '@angular/material/stepper';
import {MatDatepickerModule} from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
// import {MatMomentDateModule} from '@angular/material-moment-adapter';
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { AppRoutes } from './app.route';
import { DashboardModule } from './dashboard.module';
import {MatSidenavModule} from '@angular/material/sidenav';
import { EmployeesListCompionent } from './employees/employees.component';
import{MatListModule} from '@angular/material/list';

      // this.getProfile()
 export const routes=[
   {path:'employees',component:EmployeesListCompionent, label :'Employees'}
]

@NgModule({
  declarations: [
    AppComponent,
    // LoginComponent,
    // HomeComponent,
    // CreateQuoteComponent,
    // DashboardComponent,
    // MenubarComponent
    EmployeesListCompionent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    RouterModule.forRoot(routes),
    MatCardModule,
    MatInputModule,
    MatButtonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatToolbarModule,
    MatIconModule,
    MatSelectModule,
    MatStepperModule,
    MatDatepickerModule,
    MatNativeDateModule,
    // MatMomentDateModule,
    MatSnackBarModule,
    DashboardModule,
    MatSidenavModule,
    MatListModule
    

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
