import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';
import { ProductList } from './product.interface';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  displayedColumns: string[] = ['policy_id', 'issue_date', 'first_name', 'email', 'premium_value', 'policy_no'];
  // dataSource!:MatTableDataSource<ProductList>;
  public dataSource: any;
  policyId:any;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort!: MatSort;

  constructor(private loginSrv: LoginService,private router:Router) {

  }

  ngOnInit(): void {
    this.getProductList();

  }

  getProductList() {
    this.loginSrv.getProdcutList()!.subscribe((res: any) => {
      console.log(res.data);
      this.dataSource = new MatTableDataSource(res.data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sortingDataAccessor = (item: any, property: any) => {
        switch (property) {
          case 'premium_value': return item.proposal.premium_value;
          case 'email':return item.proposal.email;
          case 'first_name':return item.proposal.first_name
          default: return item[property];
        }
      };
      this.dataSource.sort = this.sort;
    })
  }
 createNewQuote(data:any){
   console.log(data);
   this.policyId=data;
   this.router.navigate(['dashboard/editpolicy'],{queryParams:{id:this.policyId,data:'policy'}});
 }
  createPolicy(){
   this.router.navigate(['dashboard/createpolicy']);

  }
  applyFilter(event:any) {
    let filterValue=event.target.value
    this.dataSource.filter = filterValue.trim().toLowerCase();
    console.log(this.dataSource.filter);
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }
}
