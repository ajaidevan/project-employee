export interface ProductList {
    policyId?: string;
    issuedDate?:string;
    proposalName?:string;
    email?:string;
    premiumAmount?:string;
    policyNo?:string
  }