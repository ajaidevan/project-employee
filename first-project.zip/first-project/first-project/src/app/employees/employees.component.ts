import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
@Component({
    selector: 'app-employees',
    templateUrl: './employees.component.html',
    styleUrls: ['./employees.component.scss']
  })

  export class EmployeesListCompionent implements OnInit {

    public dataSource: any;
  policyId:any;
  displayedColumns: string[] = ['id','name', 'email', 'locations', 'role', 'createdAt','action'];
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort!: MatSort;
  public employeesData=[
    {
        "id":"1",
        "name":"xxxyz",
        "email":"xyz@gmail.com",
        "role":"Item",
       "locations":"All locattions",
       "createdAt":"24-07-2021"
    },
    {
        "id":"2",
        "name":"xxxxyz",
        "email":"zzz@gmail.com",
        "role":"Admin",
       "locations":"All locattions",
       "createdAt":"24-07-2021"
    },
    {
        "id":"3",
        "name":"xyz",
        "email":"ccz@gmail.com",
        "role":"Master",
       "locations":"All locattions",
       "createdAt":"24-07-2021"
    },
    {
        "id":"4",
        "name":"xyz",
        "email":"ddz@gmail.com",
        "role":"Admin",
       "locations":"All locattions",
       "createdAt":"24-07-2021"
    },
    {
        "id":"5",
        "name":"xyz",
        "email":"xyz@gmail.com",
        "role":"Item",
       "locations":"All locattions",
       "createdAt":"24-07-2021"
    }
]


    constructor(private router:Router) { }
  
    ngOnInit(): void {
      this.employeeList()
    }
    employeeList(){
      this.dataSource = new MatTableDataSource(this.employeesData);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;

    }
  }