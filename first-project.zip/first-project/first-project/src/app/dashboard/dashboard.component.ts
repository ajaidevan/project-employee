import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../login/login.service';
import { routes} from '../dashboard.routing.module'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
  username!:string;
  routes = routes;
  constructor(private router:Router,private loginSrv:LoginService) { }

  ngOnInit(): void {
    // this.getProfile()
  }
  // getProfile(){
  //   this.loginSrv.getProfile()!.pipe().subscribe((res:any)=>{
  //      this.username=res.data.name;
  //   })
  // }
  logout(){
    this.router.navigate(['/login']);
  }
  navigatePolicy(){
    this.router.navigateByUrl('dashboard/home')
  }
  navigateQuote(){
    this.router.navigateByUrl('dashboard/quote-list')
  }
}
