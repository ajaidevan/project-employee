import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MY_FORMATS } from './create-quote/create-quote.component';
import { DashboardRoutingModule } from './dashboard.routing.module';
import { LoginService } from './login/login.service';

import { AuthService } from './services/authentication.service';



@NgModule({
    declarations: [

    ],
    imports: [

        DashboardRoutingModule
    ],
    providers: [LoginService, AuthService,DatePipe,
        {provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE]},

        {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},],

})
export class DashboardModule { }