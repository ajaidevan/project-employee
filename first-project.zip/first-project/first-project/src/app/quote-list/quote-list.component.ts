import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';

@Component({
    selector: 'app-quote-list',
    templateUrl: './quote-list.component.html',
    styleUrls: ['./quote-list.component.scss']
  })

  export class QuoteListComponent implements OnInit{

  public dataSource: any;
  policyId:any;
  displayedColumns: string[] = ['policy_id','quote_id', 'quote_date', 'email', 'quote_no', 'purpose'];
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort!: MatSort;


    constructor(private loginSrv: LoginService,private router:Router) {

    }
    ngOnInit(){
      this.getQuoteList();
    }
    getQuoteList(){
        this.loginSrv.quoteList().pipe().subscribe((res:any)=>{
            console.log(res);
            this.dataSource = new MatTableDataSource(res.data);
            this.dataSource.paginator = this.paginator;
            this.dataSource.sortingDataAccessor = (item: any, property: any) => {
                switch (property) {
                  case 'quote_id': return item.quote.quote_id;
                  case 'email':return item.quote.email;
                  case 'quote_no':return item.quote.quote_no
                  default: return item[property];
                }
              };
              this.dataSource.sort = this.sort;
            })
        // res.data.map((ele:any)=>{
        //     console.log(ele.policy_no);
            
        // })
    }
    createNewQuote(data:any){
        console.log(data);
        this.policyId=data;
        this.router.navigate(['dashboard/editpolicy'],{queryParams:{id:this.policyId,data:'quote'}});
      }
      applyFilter(event:any) {
        let filterValue=event.target.value
        this.dataSource.filter = filterValue.trim().toLowerCase();
        console.log(this.dataSource.filter);
        if (this.dataSource.paginator) {
          this.dataSource.paginator.firstPage();
        }
      }
  }