import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import{LoginComponent} from './login.component'
import { BehaviorSubject, Observable } from 'rxjs';
import { MatSnackBar } from '@angular/material/snack-bar';


const HTTP_OPTIONS={
  headers:new HttpHeaders({
    'Content-Type':'application/json',
    'in-auth-token':sessionStorage.getItem('in-auth-token')!
  })
}
@Injectable({ providedIn: 'root' })


export class LoginService {
    constructor(private http: HttpClient,private snackBar:MatSnackBar) {this.myMethod$ = this.myMethodSubject.asObservable(); }
    myMethod$!: Observable<any>;
    authToken:any;
    private myMethodSubject = new BehaviorSubject<any>("");
    header:any;
   
    // authenticate(user: any){
    //     return this.http.post(`https://apitest.cloware.in/api/v1/auth`,user )
    //     // .pipe(map((res:any)=>{
    //     //     console.log(res.data.token);
    //     //    this.token= sessionStorage.setItem('Authorization',"Bearer" + res.data.token);

    //     // }))
    // }
    myMethod(data:any) {
        console.log(data); // I have data! Let's return it so subscribers can use it!
        // we can do stuff with data if we want
        this.myMethodSubject.next(data);
        this.authToken=data;
    //  console.log((sessionStorage.getItem(this.authToken)!));
        
    }
    getProdcutList(){
      let header=new HttpHeaders().set(
        'in-auth-token' + '',
         sessionStorage.getItem('in-auth-token')!
        )
        return this.http.get(`https://apitest.cloware.in/api/v1/policy/list?u_ts__start=2021-01-31&u_ts__end=2021-06-11&product_id=M000000000001&fields="policy.*,quote.*,proposal.*`, {headers:header})
    }
    getProfile(){
      if(sessionStorage.getItem('in-auth-token')!=null){
      let header=new HttpHeaders().set(
        'in-auth-token' + '',
         sessionStorage.getItem('in-auth-token')!
        )
      return this.http.get(`https://apitest.cloware.in/api/v1/profile`,{headers:header});
      }
    }

    getPolicyById(policyId:any){
      let header=new HttpHeaders().set(
        'in-auth-token' + '',
         sessionStorage.getItem('in-auth-token')!
        )
      return this.http.get(`https://apitest.cloware.in/api/v1/policy/${policyId}`,{headers:header})
  }
  getProductCalc(){
  console.log(HTTP_OPTIONS);
  let header=new HttpHeaders().set(
    'in-auth-token' + '',
     sessionStorage.getItem('in-auth-token')!
    )
    return this.http.post(`https://apitest.cloware.in/api/v1/product/calc?product_id=M000000000001`,{},HTTP_OPTIONS);
  }
 getPremium(data:any){
  return this.http.post(`https://apitest.cloware.in/api/v1/product/calc/M000000000001`,data,HTTP_OPTIONS);

 }
 saveQuotation(data:any){
  return this.http.post(`https://apitest.cloware.in/api/v1/quote`,data,HTTP_OPTIONS);
 }
 quotationFinalise(data:any){
   console.log(data);
   
  return this.http.post(`https://apitest.cloware.in/api/v1/quote/finalize`,data,HTTP_OPTIONS);
 }
 showSnackbar(msg:any,){
  this.snackBar.open(msg,'',{
   duration:2500,
   horizontalPosition:'right',
   verticalPosition:'top',
   panelClass:'blue-snackbar'
  })
 }
 saveProposal(data:any){
  return this.http.post(`https://apitest.cloware.in/api/v1/proposal`,data,HTTP_OPTIONS);
 }
 finalize(data:any){
  return this.http.post(`https://apitest.cloware.in/api/v1/proposal/finalize`,data,HTTP_OPTIONS);
 }
 payment(paymentId:number,data:any){
  return this.http.post(`https://apitest.cloware.in/api/v1/payment/cash/`+paymentId,data,HTTP_OPTIONS)
 }
 download(policyId:number){
  return this.http.get(`https://apitest.cloware.in/api/v1/policy/download/`+policyId +`?token=`+sessionStorage.getItem('in-auth-token'));
 }

 quoteList(){
  let header=new HttpHeaders().set(
    'in-auth-token' + '',
     sessionStorage.getItem('in-auth-token')!
    )
return this.http.get(`https://apitest.cloware.in/api/v1/policy/list?u_ts__start=2021-05-01&u_ts__end=2021-06-11&status=0&product_id=M000000000001&fields="policy.*,quote.*,proposal.*`, {headers:header})

 }

}