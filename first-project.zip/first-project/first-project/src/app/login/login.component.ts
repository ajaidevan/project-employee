import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../services/authentication.service';
import { LoginService } from './login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  
  constructor( private formBuilder: FormBuilder,private loginSrv:LoginService,private router:Router,private authSrv:AuthService) { }
  
  public loginForm!:FormGroup;
  loading = false;
  submitted = false;
  errorMsg:any;
  token:any;
  authToken:any;
  login:boolean=false;
  username!:string;
  ngOnInit(): void {
    this.errorMsg=null;
    this.loginForm = this.formBuilder.group({
      email: ['', Validators.required],
      pwd: ['', Validators.required]
  });

  }
  onSubmit(data:any) {
    console.log('yes');
    console.log(data);
    
    this.submitted = true;
     
    // stop here if form is invalid
    
    this.authSrv.authenticate(data).subscribe((res:any)=>{
      this.errorMsg=null;
          if(res.status=='-101'){
            this.errorMsg="Incorrect Username or Password"
          }
          else if(res.status=='0'){
            this.login=true;
            this.loginSrv.showSnackbar('login Successful')
            this.router.navigate(['/dashboard']);
            // console.log(res.data.token);
            this.token=res.data.token;
            this.loginSrv.myMethod(this.token);
            this.getToken(this.token)
          }
          
       })
       
  }
   
  getError(el:any) {
    switch (el) {
      case 'user':
        if (this.loginForm.get('email')?.hasError('required')) {
          return 'Username required';
        }
        break;
      case 'pass':
        if (this.loginForm.get('pwd')?.hasError('required')) {
          return 'Password required';
        }
        break;
      default:
        return '';
    }
  }
  
  getToken(data?:any){
    console.log(data)
    
    if(data){
      this.authToken= sessionStorage.setItem('in-auth-token',"" + data);
      console.log(this.authToken);
      
      // this.loginSrv.myMethod(this.authToken);
    }
    else{
      return null;
    }
 
  }

}
