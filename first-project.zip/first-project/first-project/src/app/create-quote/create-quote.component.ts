import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit, SimpleChanges, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatStepper } from '@angular/material/stepper';
import { ActivatedRoute } from '@angular/router';
import { LoginService } from '../login/login.service';
import { AuthService } from '../services/authentication.service';
import { DatePipe } from '@angular/common';
import {MomentDateAdapter} from '@angular/material-moment-adapter';
import {DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE} from '@angular/material/core';
import * as _moment from 'moment';
import {defaultFormat as _rollupMoment} from 'moment';

const moment = _rollupMoment || _moment;


export const MY_FORMATS = {
  parse: {
    dateInput: 'LL',
  },
  display: {
    dateInput: 'DD-MM-yyyy',
    monthYearLabel: 'yyyy',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'YYYY',
  },
};

@Component({
  selector: 'app-create-quote',
  templateUrl: './create-quote.component.html',
  styleUrls: ['./create-quote.component.scss']
})
export class CreateQuoteComponent implements OnInit {

  @ViewChild('stepper') stepper!: MatStepper;
  pageName!: string;
  quoteForm!: FormGroup;
  dropDownLists: any;
  gender: any = [];
  country: any = [];
  purpose: any = [];
  relation1: any = [];
  isLinear = true;
  duration: any = [];
  plan: any = [];
  proposerNationality: any = [];
  proposerOccupation: any = [];
  proposerGST: any = [];
  b: any = [];
  basepremium: any;
  gstAmount: any;
  premiumValue: any;
  proposal: boolean = false;
  quote_id: any;
  saveproposal: boolean = false;
  editable: boolean = false;
  proposal_id: any;
  finalizeProposal: boolean = false;
  payment_id: any;
  premium_value: any;
  finalProposal: boolean = false;
  policy_id:any;
  days:any;
  patchValueData:any;
  constructor(private formBuilder: FormBuilder, private route: ActivatedRoute, 
    private loginSrv: LoginService, private authSrv: AuthService,private datePipe: DatePipe) { }

  ngOnInit(): void {
    this.loginSrv.getProductCalc().pipe().subscribe((res: any) => {
      this.dropDownLists = res.data.named_lists;
      console.log(this.dropDownLists);

      this.gender = Object.values(res.data.named_lists.gender);
      this.country = Object.values(res.data.named_lists.country);
      this.purpose = Object.values(res.data.named_lists.purpose);
      this.relation1 = Object.values(res.data.named_lists.relation1);
      this.duration = Object.values(res.data.named_lists.max_duration);
      this.plan = Object.values(res.data.named_lists.plan);
      this.proposerNationality = Object.values(res.data.named_lists.proposer_nationality);
      this.proposerOccupation = Object.values(res.data.named_lists.proposer_income_source);
      this.proposerGST = Object.values(res.data.named_lists.proposer_has_gstin);

    })
    this.route.data.subscribe(data => {
      this.pageName = data.viewOption == 'create' ? 'Create' : 'Edit';
      switch (data.viewOption) {
        case 'create':
          this.getFormCollection(data.viewOption)
          break;
        case 'update':
          let policyId = this.route.snapshot.queryParamMap.get('id');
          let sourceData=this.route.snapshot.queryParamMap.get('data');
          console.log(sourceData);
          
          console.log(policyId);
          this.loginSrv.getPolicyById(policyId).pipe().subscribe((res: any) => {
            console.log(res.data);
            this.getFormCollection(res.data[0]);
            this.patchValueData=res.data[0];
      console.log(this.patchValueData.quote.data.dob_1);

      // this.quoteForm.get('quote.dob_1')?.setValue(this.datePipe.transform(this.patchValueData.quote.data.dob_1 ,'M-d-yyyy'));

            // this.getFormCollection(data)
            if(sourceData=='policy'){
              this.quoteForm.disable();
            };

          });


          break
      }
    })
  }
  ngOnChanges(changes: SimpleChanges) {
    if (changes.order && changes.order.currentValue) {
      
    }
  }
  getFormCollection(data: any) {
    console.log(data.quote);
    this.quoteForm = this.formBuilder.group({
      quote: this.formBuilder.group({
        quote_id: (data == 'create') ? [""] : (data.quote.quote_id != null) ? [data.quote.quote_id] : [""],
        gender: (data == 'create') ? [""] : (data.quote.data.gender != null) ? [data.quote.data.gender] : [''],
        country: (data == 'create') ? [""] : (data.quote.data.country != null) ? [data.quote.data.country] : [""],
        purpose: (data == 'create') ? [""] : (data.quote.data.purpose != null) ? [data.quote.data.purpose] : [''],
        relation1: (data == 'create') ? [""] : (data.quote.data.relation1 != null) ? [data.quote.data.relation1] : [""],
        relation2: (data == 'create') ? [""] : (data.quote.data.relation2 != null) ? [data.quote.data.relation2] : [''],
        relation3: (data == 'create') ? [""] : (data.quote.data.relation3 != null) ? [data.quote.data.relation3] : [''],
        relation4: (data == 'create') ? [""] : (data.quote.data.relation4 != null) ? [data.quote.data.relation4] : [''],
        relation5: (data == 'create') ? [""] : (data.quote.data.relation5 != null) ? [data.quote.data.relation5] : [''],
        relation6: (data == 'create') ? [""] : (data.quote.data.relation6 != null) ? [data.quote.data.relation6] : [''],
        relation7: (data == 'create') ? [""] : (data.quote.data.relation7 != null) ? [data.quote.data.relation7] : [''],
        relation8: (data == 'create') ? [""] : (data.quote, data.relation8 != null) ? [data.quote.data.relation8] : [''],
        dob_1: (data == 'create') ? [] : (data.quote.data.dob_1 != null) ? [data.quote.data.dob_1] : [''],
        dob_2: (data == 'create') ? [""] : (data.quote.data.dob_2 != null) ? [data.quote.data.dob_2] : [''],
        dob_3: (data == 'create') ? [""] : (data.quote.data.dob_3 != null) ? [data.quote.data.dob_3] : [''],
        dob_4: (data == 'create') ? [""] : (data.quote.data.dob_4 != null) ? [data.quote.data.dob_4] : [''],
        dob_5: (data == 'create') ? [""] : (data.quote.data.dob_5 != null) ? [data.quote.data.dob_5] : [''],
        dob_6: (data == 'create') ? [""] : (data.quote.data.dob_6 != null) ? [data.quote.data.dob_6] : [''],
        dob_7: (data == 'create') ? [""] : (data.quote.data.dob_7 != null) ? [data.quote.data.dob_7] : [''],
        dob_8: (data == 'create') ? [""] : (data.quote.data.dob_8 != null) ? [data.quote.data.dob_8] : [''],
        trip_start_date: (data == 'create') ? [""] : (data.quote.data.trip_start_date != null) ? [data.quote.data.trip_start_date] : [''],
        trip_end_date: (data == 'create') ? [""] : (data.quote.data.trip_end_date != null) ? [data.quote.data.trip_end_date] : [''],
        duration: (data == 'create') ? [""] : (data.quote.data.duration != null) ? [data.quote.data.duration] : [''],
        max_duration: (data == 'create') ? [""] : (data.quote.data.max_duration != null) ? [data.quote.data.max_duration] : [''],
        plan: (data == 'create') ? [""] : (data.quote.data.plan != null) ? [data.quote.data.plan] : [''],
        base_premium: (data == 'create') ? [""] : (data.proposal.data.base_premium != null) ? [data.proposal.data.base_premium] : [''],
        gst_amount: (data == 'create') ? [""] : (data.proposal.data.gst_amount != null) ? [data.proposal.data.gst_amount] : [''],
        premium_value: (data == 'create') ? [""] : (data.proposal.data.premium_value != null) ? [data.proposal.data.premium_value] : ['']
      }),
      proposal: this.formBuilder.group({
        proposal_id: (data == 'create') ? [""] : (data.proposal.proposal_id != null) ? [data.proposal.proposal_id] : [''],
        policy_start_date: (data == 'create') ? [""] : (data.proposal.data.policy_start_date != null) ? [data.proposal.data.policy_start_date] : [''],
        policy_end_date: (data == 'create') ? [''] : (data.proposal.data.policy_end_date != null) ? [data.proposal.data.policy_end_date] : [''],
        proposer_nationality: (data == 'create') ? [''] : (data.proposal.data.proposer_nationality != null) ? [data.proposal.data.proposer_nationality] : [''],
        proposer_name: (data == 'create') ? ['', Validators.required] : (data.proposal.data.proposer_name != null) ? [data.proposal.data.proposer_name] : [''],
        proposer_address_bldg: (data == 'create') ? [''] : (data.proposal.data.proposer_address_bldg != null) ? [data.proposal.data.proposer_address_bldg] : [''],
        proposer_address_road: (data == 'create') ? [''] : (data.proposal.data.proposer_address_road != null) ? [data.proposal.data.proposer_address_road] : [''],
        proposer_address_area: (data == 'create') ? [''] : (data.proposal.data.proposer_address_area != null) ? [data.proposal.data.proposer_address_area] : [''],
        proposer_address_landmark: (data == 'create') ? [''] : (data.proposal.data.proposer_address_landmark != null) ? [data.proposal.data.proposer_address_landmark] : [''],
        proposer_address_pincode: (data == 'create') ? [''] : (data.proposal.data.proposer_address_pincode != null) ? [data.proposal.data.proposer_address_pincode] : [''],
        mobile_no: (data == 'create') ? [''] : (data.proposal.data.mobile_no != null) ? [data.proposal.data.mobile_no] : [''],
        email: (data == 'create') ? [''] : (data.proposal.data.email != null) ? [data.proposal.data.email] : [''],
        proposer_income_source: (data == 'create') ? [''] : (data.proposal.data.proposer_income_source != null) ? [data.proposal.data.proposer_income_source] : [''],
        proposer_has_gstin: (data == 'create') ? [''] : (data.proposal.data.proposer_has_gstin != null) ? [data.proposal.data.proposer_has_gstin] : [''],
        proposer_gstin: (data == 'create') ? [''] : (data.proposal.data.proposer_gstin != null) ? [data.proposal.data.proposer_gstin] : [''],
        traveller_1: (data == 'create') ? [''] : (data.proposal.data.traveller_1 != null) ? [data.proposal.data.traveller_1] : [''],
        traveller_2: (data == 'create') ? [''] : (data.proposal.data.traveller_2 != null) ? [data.proposal.data.traveller_2] : [''],
        traveller_3: (data == 'create') ? [''] : (data.proposal.data.traveller_3 != null) ? [data.proposal.data.traveller_3] : [''],
        traveller_4: (data == 'create') ? [''] : (data.proposal.data.traveller_4 != null) ? [data.proposal.data.traveller_4] : [''],
        traveller_5: (data == 'create') ? [''] : (data.proposal.data.traveller_5 != null) ? [data.proposal.data.traveller_5] : [''],
        traveller_6: (data == 'create') ? [''] : (data.proposal.data.traveller_6 != null) ? [data.proposal.data.traveller_6] : [''],
        traveller_7: (data == 'create') ? [''] : (data.proposal.data.traveller_7 != null) ? [data.proposal.data.traveller_7] : [''],
        traveller_8: (data == 'create') ? [''] : (data.proposal.data.traveller_8 != null) ? [data.proposal.data.traveller_8] : [''],
        passport_1: (data == 'create') ? [''] : (data.proposal.data.passport_1 != null) ? [data.proposal.data.passport_1] : [''],
        passport_2: (data == 'create') ? [''] : (data.proposal.data.passport_2 != null) ? [data.proposal.data.passport_2] : [''],
        passport_3: (data == 'create') ? [''] : (data.proposal.data.passport_3 != null) ? [data.proposal.data.passport_3] : [''],
        passport_4: (data == 'create') ? [''] : (data.proposal.data.passport_4 != null) ? [data.proposal.data.passport_4] : [''],
        passport_5: (data == 'create') ? [''] : (data.proposal.data.passport_5 != null) ? [data.proposal.data.passport_5] : [''],
        passport_6: (data == 'create') ? [''] : (data.proposal.data.passport_6 != null) ? [data.proposal.data.passport_6] : [''],
        passport_7: (data == 'create') ? [''] : (data.proposal.data.passport_7 != null) ? [data.proposal.data.passport_7] : [''],
        passport_8: (data == 'create') ? [''] : (data.proposal.data.passport_8 != null) ? [data.proposal.data.passport_8] : [''],

        nominee_1_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_1_relation != null) ? [data.proposal.data.nominee_1_relation] : [''],
        nominee_2_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_2_relation != null) ? [data.proposal.data.nominee_2_relation] : [''],
        nominee_3_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_3_relation != null) ? [data.proposal.data.nominee_3_relation] : [''],
        nominee_4_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_4_relation != null) ? [data.proposal.data.nominee_4_relation] : [''],
        nominee_5_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_5_relation != null) ? [data.proposal.data.nominee_5_relation] : [''],
        nominee_6_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_6_relation != null) ? [data.proposal.data.nominee_6_relation] : [''],
        nominee_7_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_7_relation != null) ? [data.proposal.data.nominee_7_relation] : [''],
        nominee_8_relation: (data == 'create') ? [''] : (data.proposal.data.nominee_8_relation != null) ? [data.proposal.data.nominee_8_relation] : [''],

        nominee_1: (data == 'create') ? [''] : (data.proposal.data.nominee_1 != null) ? [data.proposal.data.nominee_1] : [''],
        nominee_2: (data == 'create') ? [''] : (data.proposal.data.nominee_2 != null) ? [data.proposal.data.nominee_2] : [''],
        nominee_3: (data == 'create') ? [''] : (data.proposal.data.nominee_3 != null) ? [data.proposal.data.nominee_3] : [''],
        nominee_4: (data == 'create') ? [''] : (data.proposal.data.nominee_4 != null) ? [data.proposal.data.nominee_4] : [''],
        nominee_5: (data == 'create') ? [''] : (data.proposal.data.nominee_5 != null) ? [data.proposal.data.nominee_5] : [''],
        nominee_6: (data == 'create') ? [''] : (data.proposal.data.nominee_6 != null) ? [data.proposal.data.nominee_6] : [''],
        nominee_7: (data == 'create') ? [''] : (data.proposal.data.nominee_7 != null) ? [data.proposal.data.nominee_7] : [''],
        nominee_8: (data == 'create') ? [''] : (data.proposal.data.nominee_8 != null) ? [data.proposal.data.nominee_8] : [''],

        nominee_1_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_1_dob != null) ? [data.proposal.data.nominee_1_dob] : [''],
        nominee_2_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_2_dob != null) ? [data.proposal.data.nominee_2_dob] : [''],
        nominee_3_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_3_dob != null) ? [data.proposal.data.nominee_3_dob] : [''],
        nominee_4_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_4_dob != null) ? [data.proposal.data.nominee_4_dob] : [''],
        nominee_5_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_5_dob != null) ? [data.proposal.data.nominee_5_dob] : [''],
        nominee_6_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_6_dob != null) ? [data.proposal.data.nominee_6_dob] : [''],
        nominee_7_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_7_dob != null) ? [data.proposal.data.nominee_7_dob] : [''],
        nominee_8_dob: (data == 'create') ? [''] : (data.proposal.data.nominee_8_dob != null) ? [data.proposal.data.nominee_8_dob] : [''],


      })

    })


  }
  premiumCalc(value: any) {
    let data = {
      inputs: {
        "relation1": this.quoteForm.controls['quote'].value.relation1 != null ? this.quoteForm.controls['quote'].value.relation1 : null,
        "dob_1": this.quoteForm.controls['quote'].value.dob_1 != "" ? this.quoteForm.controls['quote'].value.dob_1 : "",
        relation2: this.quoteForm.controls['quote'].value.relation2 != null ? this.quoteForm.controls['quote'].value.relation2 : undefined,
        "relation3": this.quoteForm.controls['quote'].value.relation3 != null ? this.quoteForm.controls['quote'].value.relation3 : null,
        "relation4": this.quoteForm.controls['quote'].value.relation4 != null ? this.quoteForm.controls['quote'].value.relation4 : null,
        "relation5": this.quoteForm.controls['quote'].value.relation5 != null ? this.quoteForm.controls['quote'].value.relation5 : null,
        "relation6": this.quoteForm.controls['quote'].value.relation6 != null ? this.quoteForm.controls['quote'].value.relation6 : null,
        "relation7": this.quoteForm.controls['quote'].value.relation7 != null ? this.quoteForm.controls['quote'].value.relation7 : null,
        "relation8": this.quoteForm.controls['quote'].value.relation8 != null ? this.quoteForm.controls['quote'].value.relation8 : null,
        "dob_2": this.quoteForm.controls['quote'].value.dob_2 != "" ? this.quoteForm.controls['quote'].value.dob_2 : "",
        "dob_3": this.quoteForm.controls['quote'].value.dob_3 != "" ? this.quoteForm.controls['quote'].value.dob_3 : "",
        "dob_4": this.quoteForm.controls['quote'].value.dob_4 != "" ? this.quoteForm.controls['quote'].value.dob_4 : "",
        "dob_5": this.quoteForm.controls['quote'].value.dob_5 != "" ? this.quoteForm.controls['quote'].value.dob_5 : "",
        "dob_6": this.quoteForm.controls['quote'].value.dob_6 != "" ? this.quoteForm.controls['quote'].value.dob_6 : "",
        "dob_7": this.quoteForm.controls['quote'].value.dob_7 != "" ? this.quoteForm.controls['quote'].value.dob_7 : "",
        "dob_8": this.quoteForm.controls['quote'].value.dob_8 != "" ? this.quoteForm.controls['quote'].value.dob_8 : "",
        "trip_start_date": this.quoteForm.controls['quote'].value.trip_start_date != "" ? this.quoteForm.controls['quote'].value.startDate : "",
        "trip_end_date": this.quoteForm.controls['quote'].value.trip_end_date != "" ? this.quoteForm.controls['quote'].value.endDate : "",
        "plan": this.quoteForm.controls['quote'].value.plan != null ? this.quoteForm.controls['quote'].value.plan : null
      },
      outputs: ["premium_value", "base_premium", "gst_amount"]
    }
    console.log(data);
    //   const filteredObj = (obj:any) =>
    // Object.entries(obj)
    //   .filter(([_, value]) => !!value || typeof value === "boolean")
    //   .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    //   console.log(filteredObj(data));

    this.loginSrv.getPremium(data).pipe().subscribe((res: any) => {
      this.basepremium = res.data.cells.base_premium;
      this.quoteForm.get('quote.base_premium')?.setValue(this.basepremium);
      this.gstAmount = res.data.cells.gst_amount;
      this.quoteForm.get('quote.gst_amount')?.setValue(this.gstAmount);
      this.premiumValue = res.data.cells.premium_value;
      this.quoteForm.get('quote.premium_value')?.setValue(this.premiumValue);

    })
  }
  saveAndProposeQuote() {
    this.stepper.selected!.completed = true;
    // this.quoteForm.value.quote.product_id = "M000000000001";
    this.quoteForm.value.quote.quote_id = this.quote_id != null ? this.quote_id : null;
    const filteredObj = (obj: any) =>
      Object.entries(obj)
        .filter(([_, value]) => !!value || typeof value === "boolean")
        .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    console.log(filteredObj(this.quoteForm.controls['quote'].value));
    this.loginSrv.quotationFinalise(filteredObj(this.quoteForm.controls['quote'].value)).pipe().subscribe((res: any) => {
      console.log(res);
      if (res.status == 0) {
        this.loginSrv.showSnackbar('Saved Successfully!');
        this.stepper.next();
        this.editable = true;
        res.data.map((proposal: any) => {
          this.proposal_id = proposal.proposal_id;
        })
        // this.quoteForm.controls['quote'].disable();

      }
      else if (res.status === -113) {
        this.loginSrv.showSnackbar(res.data)
      }
    })
  }

  saveQuote() {
    (this.quoteForm.get('quote') as FormGroup).removeControl('premium_value');
    (this.quoteForm.get('quote') as FormGroup).removeControl('base_premium');;
    (this.quoteForm.get('quote') as FormGroup).removeControl('gst_amount');;
    this.quoteForm.value.quote.product_id = "M000000000001";
    this.quoteForm.value.quote.quote_id = this.quote_id != null ? this.quote_id : null;
    const filteredObj = (obj: any) =>
      Object.entries(obj)
        .filter(([_, value]) => !!value || typeof value === "boolean")
        .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    this.loginSrv.saveQuotation(filteredObj(this.quoteForm.controls['quote'].value)).pipe().subscribe((res: any) => {
      if (res.status == 0) {
        this.loginSrv.showSnackbar('Saved Successfully!');
        this.saveproposal = true;
        //  this.quote_id=res.data.quote;
        res.data.map((quote: any) => {
          this.quote_id = quote.quote_id;
        })
      }
      else if (res.status = "-107") {
        this.loginSrv.showSnackbar(res.txt);
      }
    })

  }
  saveProposal() {
    this.quoteForm.value.proposal.proposal_id = this.proposal_id != null ? this.proposal_id : null;
    const filteredObj = (obj: any) =>
      Object.entries(obj)
        .filter(([_, value]) => !!value || typeof value === "boolean")
        .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    console.log(this.quoteForm.controls['proposal'].value);

    this.loginSrv.saveProposal(filteredObj(this.quoteForm.controls['proposal'].value)).pipe().subscribe((res: any) => {
      console.log(res);
      if (res.status == 0) {
        this.finalizeProposal = true;
        this.loginSrv.showSnackbar('saved successfully')
      }
    })

  }
  finalize() {
    this.quoteForm.value.proposal.proposal_id = this.proposal_id != null ? this.proposal_id : null;
    const filteredObj = (obj: any) =>
      Object.entries(obj)
        .filter(([_, value]) => !!value || typeof value === "boolean")
        .reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
    console.log(this.quoteForm.controls['proposal'].value);

    this.loginSrv.finalize(filteredObj(this.quoteForm.controls['proposal'].value)).pipe().subscribe((res: any) => {
      console.log(res);
      if (res.status == 0) {
        res.data.map((ele: any) => {
          this.loginSrv.showSnackbar('Saved And finalized Successfully!')
          this.payment_id = ele.payment_id;
          this.premium_value = ele.proposal.premium_value;
          this.policy_id=ele.proposal.policy_id;
          this.finalProposal = true;
          this.stepper.selected!.completed = true;
          this.stepper.next();
        })
      }
    })
  }
  payment() {
    this.loginSrv.payment(this.payment_id, { amount: this.premium_value }).pipe().subscribe((res: any) => {
      console.log(res);
      if (res.status == 0) {
        this.loginSrv.showSnackbar(res.txt)
      }

    })

  }
  savePdf(){
    this.loginSrv.download(this.policy_id).pipe().subscribe((res:any)=>{
      console.log(res);
      if(res.status==0){

      }
      else{
        this.loginSrv.showSnackbar('Failed To Download!')
      }

    })
  }
  calculateDiff(value:any){
    if(this.quoteForm.controls['quote'].value.trip_start_date !=null && this.quoteForm.controls['quote'].value.trip_end_date!=null){
    let date = new Date(this.quoteForm.controls['quote'].value.trip_start_date);
    let currentDate = new Date(this.quoteForm.controls['quote'].value.trip_end_date);
    this.days=Math.floor((currentDate.getTime() - date.getTime()) / 1000 / 60 / 60 / 24);
    }
  }
  date(){
  console.log(this.quoteForm.controls['quote'].value.dob_1);
  let a=this.datePipe.transform(this.quoteForm.controls['quote'].value.dob_1,'dd-MM-yyyy');
  console.log(a);
  
  }
}
